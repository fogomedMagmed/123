<?php
// Начинаем сессию
session_start();

// Подключаем файл с функциями
require_once '../includes/functions.php';

// Если пользователь не авторизован или не является администратором, возвращаем ошибку
if (!isLoggedIn() || $_SESSION['user']['role'] !== 'admin') {
   http_response_code(403);
   exit('Доступ запрещен');
}

// Подключаемся к базе данных
$pdo = require '../config/database.php';

// Получаем список активных чатов
$stmt = $pdo->prepare("
  SELECT c.*, u.name as user_name, u.email as user_email,
  (SELECT COUNT(*) FROM chat_messages WHERE chat_id = c.id AND is_read = 0 AND sender_type = 'user') as unread_count
  FROM chats c
  JOIN users u ON c.user_id = u.id
  WHERE c.status != 'closed'
  ORDER BY c.status = 'waiting_for_operator' DESC, c.updated_at DESC
");
$stmt->execute();
$chats = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Получаем ID выбранного чата
$selectedChatId = isset($_GET['chat_id']) ? (int)$_GET['chat_id'] : 0;
?>

<?php if (count($chats) > 0): ?>
   <?php foreach ($chats as $chat): ?>
       <a 
           href="/admin/chats.php?chat_id=<?php echo $chat['id']; ?>" 
           class="block p-4 border-b border-zinc-800 hover:bg-zinc-800 transition-colors <?php echo $selectedChatId === $chat['id'] ? 'bg-zinc-800' : ''; ?>"
       >
           <div class="flex items-center justify-between">
               <div>
                   <div class="font-medium"><?php echo htmlspecialchars($chat['user_name']); ?></div>
                   <div class="text-sm text-gray-400"><?php echo htmlspecialchars($chat['user_email']); ?></div>
               </div>
               <?php if ($chat['status'] === 'waiting_for_operator'): ?>
                   <div class="bg-yellow-500 text-black text-xs px-2 py-1 rounded-full">Ожидает</div>
               <?php endif; ?>
               <?php if ($chat['unread_count'] > 0): ?>
                   <div class="bg-red-500 text-white text-xs px-2 py-1 rounded-full"><?php echo $chat['unread_count']; ?></div>
               <?php endif; ?>
           </div>
           <div class="text-xs text-gray-500 mt-1">
               <?php echo date('d.m.Y H:i', strtotime($chat['updated_at'])); ?>
           </div>
       </a>
   <?php endforeach; ?>
<?php else: ?>
   <div class="p-4 text-center text-gray-500">
       Нет активных чатов
   </div>
<?php endif; ?>