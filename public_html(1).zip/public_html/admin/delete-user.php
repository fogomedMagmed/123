<?php
// Начинаем сессию
session_start();

// Подключаем файл с функциями
require_once '../includes/functions.php';

// Если пользователь не авторизован или не является администратором, перенаправляем на главную
if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../index.php');
    exit;
}

// Подключаемся к базе данных
$pdo = require '../config/database.php';

// Получаем ID пользователя из URL
$userId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Проверяем, что ID пользователя передан и не является ID текущего пользователя
if ($userId === 0) {
    $_SESSION['admin_error'] = 'Не указан ID пользователя';
    header('Location: users.php');
    exit;
}

if ($userId === $_SESSION['user']['id']) {
    $_SESSION['admin_error'] = 'Вы не можете удалить свой аккаунт';
    header('Location: users.php');
    exit;
}

// Проверяем, существует ли пользователь
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) {
    $_SESSION['admin_error'] = 'Пользователь не найден';
    header('Location: users.php');
    exit;
}

// Если форма подтверждения отправлена
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    try {
        // Начинаем транзакцию
        $pdo->beginTransaction();
        
        // Удаляем аватар пользователя, если он есть
        if (!empty($user['avatar']) && $user['avatar'] !== 'assets/images/avatars/default.png' && file_exists('../' . $user['avatar'])) {
            unlink('../' . $user['avatar']);
        }
        
        // Удаляем товары пользователя, если он продавец
        if ($user['role'] === 'seller' || $user['role'] === 'admin') {
            // Получаем все товары пользователя
            $stmt = $pdo->prepare("SELECT * FROM products WHERE seller_id = ?");
            $stmt->execute([$userId]);
            $products = $stmt->fetchAll();
            
            // Удаляем изображения товаров
            foreach ($products as $product) {
                if (!empty($product['image']) && file_exists('../' . $product['image'])) {
                    unlink('../' . $product['image']);
                }
            }
            
            // Удаляем товары из базы данных
            $stmt = $pdo->prepare("DELETE FROM products WHERE seller_id = ?");
            $stmt->execute([$userId]);
        }
        
        // Удаляем чаты пользователя
        $stmt = $pdo->prepare("SELECT * FROM chats WHERE user_id = ?");
        $stmt->execute([$userId]);
        $chats = $stmt->fetchAll();
        
        foreach ($chats as $chat) {
            // Удаляем сообщения чата
            $stmt = $pdo->prepare("DELETE FROM chat_messages WHERE chat_id = ?");
            $stmt->execute([$chat['id']]);
            
            // Удаляем назначения чата операторам
            $stmt = $pdo->prepare("DELETE FROM chat_assignments WHERE chat_id = ?");
            $stmt->execute([$chat['id']]);
        }
        
        // Удаляем чаты пользователя
        $stmt = $pdo->prepare("DELETE FROM chats WHERE user_id = ?");
        $stmt->execute([$userId]);
        
        // Удаляем пользователя
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        
        // Завершаем транзакцию
        $pdo->commit();
        
        $_SESSION['admin_success'] = 'Пользователь успешно удален';
        header('Location: users.php');
        exit;
    } catch (PDOException $e) {
        // Откатываем транзакцию в случае ошибки
        $pdo->rollBack();
        
        $_SESSION['admin_error'] = 'Ошибка при удалении пользователя: ' . $e->getMessage();
        header('Location: users.php');
        exit;
    }
}

// Подключаем шапку сайта
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="mb-4">
        <a href="/admin/users.php" class="text-zinc-400 hover:text-white transition-colors">
            ← Назад к списку пользователей
        </a>
    </div>
    
    <div class="bg-zinc-900 border border-zinc-800 rounded-lg p-6 max-w-lg mx-auto">
        <h1 class="text-2xl font-bold mb-6 text-center text-white">Удаление пользователя</h1>
        
        <div class="text-center mb-6">
            <p class="text-zinc-300 mb-4">Вы действительно хотите удалить пользователя <strong><?php echo htmlspecialchars($user['name']); ?></strong> (<?php echo htmlspecialchars($user['email']); ?>)?</p>
            <p class="text-red-400 mb-4">Это действие нельзя отменить. Все данные пользователя, включая товары и сообщения, будут удалены.</p>
        </div>
        
        <div class="flex justify-center space-x-4">
            <a href="/admin/users.php" class="px-4 py-2 bg-zinc-700 hover:bg-zinc-600 text-white rounded-md transition-colors">
                Отмена
            </a>
            <form method="post" action="">
                <input type="hidden" name="confirm_delete" value="1">
                <button type="submit" class="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-md transition-colors">
                    Удалить
                </button>
            </form>
        </div>
    </div>
</div>

<?php
// Подключаем подвал сайта
include '../includes/footer.php';
?>

