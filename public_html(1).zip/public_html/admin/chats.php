<?php
// Начинаем сессию
session_start();

// Подключаем файл с функциями
require_once '../includes/functions.php';

// Если пользователь не авторизован или не является администратором, перенаправляем на главную
if (!isLoggedIn() || !isAdmin()) {
   header('Location: ../index.php');
   exit;
}

// Подключаемся к базе данных
$pdo = require '../config/database.php';

// Получаем ID выбранного чата из URL
$selectedChatId = isset($_GET['chat_id']) ? (int)$_GET['chat_id'] : 0;

// Получаем сообщения выбранного чата
$messages = [];
if ($selectedChatId > 0) {
   try {
       // Получаем информацию о чате
       $stmt = $pdo->prepare("
           SELECT c.*, u.name as user_name, u.email as user_email
           FROM chats c
           JOIN users u ON c.user_id = u.id
           WHERE c.id = ?
       ");
       $stmt->execute([$selectedChatId]);
       $chat = $stmt->fetch(PDO::FETCH_ASSOC);
       
       if ($chat) {
           // Получаем сообщения чата
           $stmt = $pdo->prepare("
               SELECT m.*, u.name as user_name
               FROM chat_messages m
               LEFT JOIN users u ON m.sender_id = u.id
               WHERE m.chat_id = ?
               ORDER BY m.created_at ASC
           ");
           $stmt->execute([$selectedChatId]);
           $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
           
           // Отмечаем сообщения как прочитанные
           $stmt = $pdo->prepare("
               UPDATE chat_messages 
               SET is_read = 1 
               WHERE chat_id = ? AND sender_type = 'user' AND is_read = 0
           ");
           $stmt->execute([$selectedChatId]);
       }
   } catch (PDOException $e) {
       // В случае ошибки просто показываем пустой список сообщений
   }
}

// Подключаем шапку сайта
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
   <div class="mb-4">
       <a href="/admin/dashboard.php" class="text-zinc-400 hover:text-white transition-colors">
           ← Назад к панели администратора
       </a>
   </div>
   
   <h1 class="text-3xl font-bold mb-6 text-white">Чаты поддержки</h1>
   
   <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
       <!-- Список чатов -->
       <div class="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
           <div class="bg-zinc-800 p-4 border-b border-zinc-700">
               <h2 class="font-medium">Активные чаты</h2>
           </div>
           
           <div id="chats-list" class="overflow-y-auto h-[calc(100vh-300px)]">
               <!-- Здесь будет список чатов, загружаемый через AJAX -->
               <div class="p-4 text-center text-gray-500">
                   Загрузка чатов...
               </div>
           </div>
       </div>
       
       <!-- Сообщения чата -->
       <div class="md:col-span-2 bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
           <?php if ($selectedChatId && isset($chat)): ?>
               <!-- Заголовок чата -->
               <div class="bg-zinc-800 p-4 border-b border-zinc-700 flex items-center justify-between">
                   <div>
                       <div class="font-medium"><?php echo htmlspecialchars($chat['user_name']); ?></div>
                       <div class="text-sm text-gray-400"><?php echo htmlspecialchars($chat['user_email']); ?></div>
                   </div>
                   <div class="flex items-center space-x-2">
                       <?php if ($chat['status'] === 'waiting_for_operator'): ?>
                           <form method="post" action="/api/chat_take.php">
                               <input type="hidden" name="chat_id" value="<?php echo $chat['id']; ?>">
                               <button type="submit" class="px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded-md text-sm">
                                   Принять чат
                               </button>
                           </form>
                       <?php endif; ?>
                       <form method="post" action="/api/chat_close.php" onsubmit="return confirm('Вы уверены, что хотите полностью удалить этот чат?');">
                           <input type="hidden" name="chat_id" value="<?php echo $chat['id']; ?>">
                           <input type="hidden" name="delete_completely" value="1">
                           <button type="submit" class="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded-md text-sm">
                               Удалить чат
                           </button>
                       </form>
                   </div>
               </div>
               
               <!-- Сообщения чата -->
               <div id="chat-messages" class="p-4 h-[calc(100vh-400px)] overflow-y-auto flex flex-col space-y-4">
                   <?php foreach ($messages as $message): ?>
                       <div class="flex <?php echo $message['sender_type'] === 'user' ? 'justify-start' : 'justify-end'; ?>">
                           <div class="max-w-xs md:max-w-md rounded-lg p-3 <?php 
                               if ($message['sender_type'] === 'user') {
                                   echo 'bg-zinc-800 text-gray-300';
                               } elseif ($message['sender_type'] === 'bot') {
                                   echo 'bg-zinc-700 text-gray-300';
                               } else {
                                   echo 'bg-blue-600 text-white';
                               }
                           ?>">
                               <div class="text-xs text-gray-500 mb-1">
                                   <?php 
                                   if ($message['sender_type'] === 'user') {
                                       echo htmlspecialchars($message['user_name'] ?? 'Пользователь');
                                   } elseif ($message['sender_type'] === 'bot') {
                                       echo 'Бот поддержки';
                                   } else {
                                       echo 'Оператор: ' . htmlspecialchars($_SESSION['user']['name']);
                                   }
                                   ?>
                               </div>
                               <div class="text-sm whitespace-pre-wrap"><?php echo htmlspecialchars($message['message']); ?></div>
                               <div class="text-xs text-gray-500 mt-1 text-right">
                                   <?php echo date('H:i', strtotime($message['created_at'])); ?>
                               </div>
                           </div>
                       </div>
                   <?php endforeach; ?>
               </div>
               
               <!-- Форма отправки сообщения -->
               <?php if ($chat['status'] !== 'closed'): ?>
                   <div class="border-t border-zinc-800 p-4">
                       <form id="operator-form" class="flex space-x-2">
                           <input type="hidden" name="chat_id" value="<?php echo $chat['id']; ?>">
                           <input 
                               type="text" 
                               name="message" 
                               id="operator-message"
                               placeholder="Введите сообщение..." 
                               class="flex-grow p-2 rounded-lg bg-zinc-800 border border-zinc-700 text-white placeholder-gray-500 focus:outline-none focus:border-zinc-600"
                               required
                           >
                           <button 
                               type="submit" 
                               class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                           >
                               Отправить
                           </button>
                       </form>
                   </div>
               <?php else: ?>
                   <div class="border-t border-zinc-800 p-4 text-center text-gray-500">
                       Чат закрыт
                   </div>
               <?php endif; ?>
           <?php else: ?>
               <div class="p-4 text-center text-gray-500">
                   Выберите чат из списка слева
               </div>
           <?php endif; ?>
       </div>
   </div>
</div>

<script>
// Функция для загрузки списка чатов
function loadChatsList() {
   fetch('/admin/get_chats_list.php?chat_id=<?php echo $selectedChatId; ?>')
       .then(response => response.text())
       .then(html => {
           document.getElementById('chats-list').innerHTML = html;
       })
       .catch(error => {
           console.error('Error loading chats list:', error);
           document.getElementById('chats-list').innerHTML = '<div class="p-4 text-center text-red-500">Ошибка загрузки чатов</div>';
       });
}

// Загружаем список чатов при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
   loadChatsList();
   
   // Обновляем список чатов каждые 10 секунд
   setInterval(loadChatsList, 10000);
   
   // Прокручиваем чат вниз при загрузке страницы
   const chatMessages = document.getElementById('chat-messages');
   if (chatMessages) {
       chatMessages.scrollTop = chatMessages.scrollHeight;
   }
   
   // Обработчик отправки сообщения оператором
   const operatorForm = document.getElementById('operator-form');
   if (operatorForm) {
       operatorForm.addEventListener('submit', function(e) {
           e.preventDefault();
           
           const chatId = this.elements.chat_id.value;
           const message = document.getElementById('operator-message').value;
           
           if (message.trim()) {
               // Отправляем сообщение на сервер
               fetch('/api/operator_send.php', {
                   method: 'POST',
                   headers: {
                       'Content-Type': 'application/x-www-form-urlencoded',
                   },
                   body: `chat_id=${chatId}&message=${encodeURIComponent(message)}`
               })
               .then(response => response.json())
               .then(data => {
                   if (data.success) {
                       // Очищаем поле ввода
                       document.getElementById('operator-message').value = '';
                       
                       // Добавляем сообщение в чат
                       const messageDiv = document.createElement('div');
                       messageDiv.className = 'flex justify-end';
                       messageDiv.innerHTML = `
                           <div class="max-w-xs md:max-w-md rounded-lg p-3 bg-blue-600 text-white">
                               <div class="text-xs text-gray-300 mb-1">
                                   Оператор: <?php echo htmlspecialchars($_SESSION['user']['name']); ?>
                               </div>
                               <div class="text-sm whitespace-pre-wrap">${message}</div>
                               <div class="text-xs text-gray-300 mt-1 text-right">
                                   ${new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                               </div>
                           </div>
                       `;
                       
                       const chatMessages = document.getElementById('chat-messages');
                       chatMessages.appendChild(messageDiv);
                       
                       // Прокручиваем чат вниз
                       chatMessages.scrollTop = chatMessages.scrollHeight;
                   } else {
                       alert('Ошибка при отправке сообщения: ' + data.error);
                   }
               })
               .catch(error => {
                   console.error('Error:', error);
                   alert('Произошла ошибка при отправке сообщения');
               });
           }
       });
   }
});
</script>

<?php
// Подключаем подвал сайта
include '../includes/footer.php';
?>