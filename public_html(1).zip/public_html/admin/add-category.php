<?php
// Начинаем сессию
session_start();

// Подключаем файл с функциями
require_once '../includes/functions.php';

// Если пользователь не авторизован или не является администратором, перенаправляем на главную
if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../index.php');
    exit;
}

// Подключаемся к базе данных
$pdo = require '../config/database.php';

// Обработка формы добавления категории
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $description = $_POST['description'] ?? '';
    
    // Проверяем, что все поля заполнены
    if (empty($name)) {
        $error = 'Название категории обязательно для заполнения';
    } else {
        try {
            // Добавляем категорию в базу данных
            $stmt = $pdo->prepare("INSERT INTO categories (name, description) VALUES (?, ?)");
            $stmt->execute([$name, $description]);
            
            $success = 'Категория успешно добавлена';
        } catch (PDOException $e) {
            $error = 'Ошибка при добавлении категории: ' . $e->getMessage();
        }
    }
}

// Подключаем шапку сайта
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="mb-4">
        <a href="/admin/dashboard.php" class="text-zinc-400 hover:text-white transition-colors">
            ← Назад к панели администратора
        </a>
    </div>
    
    <h1 class="text-3xl font-bold mb-6 text-white">Добавить новую категорию</h1>
    
    <div class="bg-zinc-900 border border-zinc-800 rounded-lg p-6 max-w-2xl mx-auto">
        <?php if ($error): ?>
            <div class="bg-red-900/30 border border-red-800 text-red-200 px-4 py-3 rounded mb-4">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="bg-green-900/30 border border-green-800 text-green-200 px-4 py-3 rounded mb-4">
                <?php echo $success; ?>
                <p class="mt-2">
                    <a href="/admin/dashboard.php" class="underline">Вернуться к панели администратора</a> или 
                    <a href="/admin/add-category.php" class="underline">добавить еще одну категорию</a>
                </p>
            </div>
        <?php endif; ?>
        
        <form method="post" action="add-category.php" class="space-y-4">
            <div class="space-y-2">
                <label for="name" class="text-zinc-300">Название категории</label>
                <input
                    id="name"
                    name="name"
                    type="text"
                    required
                    class="w-full bg-zinc-800 border border-zinc-700 rounded p-2 text-white"
                >
            </div>
            
            <div class="space-y-2">
                <label for="description" class="text-zinc-300">Описание категории</label>
                <textarea
                    id="description"
                    name="description"
                    rows="4"
                    class="w-full bg-zinc-800 border border-zinc-700 rounded p-2 text-white"
                ></textarea>
            </div>
            
            <button type="submit" class="w-full bg-white hover:bg-gray-200 text-black py-2 px-4 rounded-md">
                Добавить категорию
            </button>
        </form>
    </div>
</div>

<?php
// Подключаем подвал сайта
include '../includes/footer.php';
?>

