<?php
// Начинаем сессию
session_start();

// Подключаем файл с функциями
require_once '../includes/functions.php';

// Если пользователь не авторизован или не является администратором, перенаправляем на главную
if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../index.php');
    exit;
}

// Подключаемся к базе данных
$pdo = require '../config/database.php';

// Получаем все заказы
$orders = [];
try {
    if ($pdo instanceof PDO) {
        // Проверяем, существует ли таблица orders
        $stmt = $pdo->query("SHOW TABLES LIKE 'orders'");
        if ($stmt->rowCount() > 0) {
            $stmt = $pdo->query("
                SELECT o.*, u.name as user_name, 
                       COUNT(oi.id) as items_count, 
                       SUM(oi.price * oi.quantity) as total_price
                FROM orders o
                JOIN users u ON o.user_id = u.id
                LEFT JOIN order_items oi ON o.id = oi.order_id
                GROUP BY o.id
                ORDER BY o.created_at DESC
            ");
            $orders = $stmt->fetchAll();
        }
    }
} catch (PDOException $e) {
    // В случае ошибки оставляем пустой массив
}

// Подключаем шапку сайта
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="mb-4">
        <a href="/admin/dashboard.php" class="text-zinc-400 hover:text-white transition-colors">
            ← Назад к панели администратора
        </a>
    </div>
    
    <h1 class="text-3xl font-bold mb-6 text-white">Управление заказами</h1>
    
    <div class="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
        <table class="w-full">
            <thead class="bg-zinc-800">
                <tr>
                    <th class="py-3 px-4 text-left text-white">ID</th>
                    <th class="py-3 px-4 text-left text-white">Пользователь</th>
                    <th class="py-3 px-4 text-center text-white">Товаров</th>
                    <th class="py-3 px-4 text-center text-white">Сумма</th>
                    <th class="py-3 px-4 text-center text-white">Статус</th>
                    <th class="py-3 px-4 text-center text-white">Дата</th>
                    <th class="py-3 px-4 text-center text-white">Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($orders)): ?>
                    <tr class="border-t border-zinc-800">
                        <td colspan="7" class="py-4 px-4 text-center text-zinc-400">Нет данных</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($orders as $order): ?>
                        <tr class="border-t border-zinc-800">
                            <td class="py-3 px-4 text-white">#<?php echo $order['id']; ?></td>
                            <td class="py-3 px-4 text-white"><?php echo $order['user_name']; ?></td>
                            <td class="py-3 px-4 text-center text-white"><?php echo $order['items_count']; ?></td>
                            <td class="py-3 px-4 text-center text-white"><?php echo $order['total_price']; ?> ₽</td>
                            <td class="py-3 px-4 text-center">
                                <?php 
                                switch ($order['status']) {
                                    case 'pending':
                                        echo '<span class="inline-block px-2 py-1 bg-yellow-900/30 text-yellow-200 rounded text-xs">Ожидает оплаты</span>';
                                        break;
                                    case 'paid':
                                        echo '<span class="inline-block px-2 py-1 bg-blue-900/30 text-blue-200 rounded text-xs">Оплачен</span>';
                                        break;
                                    case 'completed':
                                        echo '<span class="inline-block px-2 py-1 bg-green-900/30 text-green-200 rounded text-xs">Выполнен</span>';
                                        break;
                                    case 'cancelled':
                                        echo '<span class="inline-block px-2 py-1 bg-red-900/30 text-red-200 rounded text-xs">Отменен</span>';
                                        break;
                                    default:
                                        echo '<span class="inline-block px-2 py-1 bg-zinc-800 text-zinc-300 rounded text-xs">В обработке</span>';
                                }
                                ?>
                            </td>
                            <td class="py-3 px-4 text-center text-zinc-400">
                                <?php echo date('d.m.Y H:i', strtotime($order['created_at'])); ?>
                            </td>
                            <td class="py-3 px-4 text-center">
                                <div class="flex justify-center space-x-2">
                                    <a href="/admin/view-order.php?id=<?php echo $order['id']; ?>" class="text-blue-400 hover:text-blue-300">
                                        Просмотр
                                    </a>
                                    <a href="/admin/edit-order.php?id=<?php echo $order['id']; ?>" class="text-blue-400 hover:text-blue-300">
                                        Редактировать
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
// Подключаем подвал сайта
include '../includes/footer.php';
?>

