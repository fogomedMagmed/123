<?php
// Начинаем сессию
session_start();

// Подключаем файл с функциями
require_once '../includes/functions.php';

// Если пользователь не авторизован или не является администратором, перенаправляем на главную
if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../index.php');
    exit;
}

// Подключаемся к базе данных
$pdo = require '../config/database.php';

// Получаем данные текущего пользователя
$user = getCurrentUser();

// Получаем статистику
$stats = [
    'total_users' => 0,
    'total_products' => 0,
    'total_orders' => 0,
    'total_revenue' => 0
];

try {
    if ($pdo instanceof PDO) {
        // Получаем количество пользователей
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
        $result = $stmt->fetch();
        $stats['total_users'] = $result['count'] ?? 0;
        
        // Получаем количество товаров
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM products");
        $result = $stmt->fetch();
        $stats['total_products'] = $result['count'] ?? 0;
        
        // Проверяем, существует ли таблица orders
        $stmt = $pdo->query("SHOW TABLES LIKE 'orders'");
        if ($stmt->rowCount() > 0) {
            // Получаем количество заказов
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM orders");
            $result = $stmt->fetch();
            $stats['total_orders'] = $result['count'] ?? 0;
            
            // Получаем общую выручку
            $stmt = $pdo->query("
                SELECT SUM(oi.price * oi.quantity) as total
                FROM orders o
                JOIN order_items oi ON o.id = oi.order_id
                WHERE o.status IN ('paid', 'completed')
            ");
            $result = $stmt->fetch();
            $stats['total_revenue'] = $result['total'] ?? 0;
        }
    }
} catch (PDOException $e) {
    // В случае ошибки оставляем нулевые значения
}

// Получаем последних зарегистрированных пользователей
$latestUsers = [];
try {
    if ($pdo instanceof PDO) {
        $stmt = $pdo->query("
            SELECT id, name, email, role, created_at
            FROM users
            ORDER BY created_at DESC
            LIMIT 5
        ");
        $latestUsers = $stmt->fetchAll();
    }
} catch (PDOException $e) {
    // В случае ошибки оставляем пустой массив
}

// Получаем последние заказы
$latestOrders = [];
try {
    if ($pdo instanceof PDO) {
        // Проверяем, существует ли таблица orders
        $stmt = $pdo->query("SHOW TABLES LIKE 'orders'");
        if ($stmt->rowCount() > 0) {
            $stmt = $pdo->query("
                SELECT o.id, o.user_id, o.status, o.created_at, u.name as user_name,
                       COUNT(oi.id) as items_count, SUM(oi.price * oi.quantity) as total_price
                FROM orders o
                JOIN users u ON o.user_id = u.id
                LEFT JOIN order_items oi ON o.id = oi.order_id
                GROUP BY o.id
                ORDER BY o.created_at DESC
                LIMIT 5
            ");
            $latestOrders = $stmt->fetchAll();
        }
    }
} catch (PDOException $e) {
    // В случае ошибки оставляем пустой массив
}

// Подключаем шапку сайта
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6 text-white">Панель администратора</h1>
    
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="bg-zinc-900 border border-zinc-800 rounded-lg p-6">
            <h3 class="text-lg font-medium mb-2 text-white">Пользователей</h3>
            <p class="text-3xl font-bold text-white"><?php echo $stats['total_users']; ?></p>
        </div>
        
        <div class="bg-zinc-900 border border-zinc-800 rounded-lg p-6">
            <h3 class="text-lg font-medium mb-2 text-white">Товаров</h3>
            <p class="text-3xl font-bold text-white"><?php echo $stats['total_products']; ?></p>
        </div>
        
        <div class="bg-zinc-900 border border-zinc-800 rounded-lg p-6">
            <h3 class="text-lg font-medium mb-2 text-white">Заказов</h3>
            <p class="text-3xl font-bold text-white"><?php echo $stats['total_orders']; ?></p>
        </div>
        
        <div class="bg-zinc-900 border border-zinc-800 rounded-lg p-6">
            <h3 class="text-lg font-medium mb-2 text-white">Общая выручка</h3>
            <p class="text-3xl font-bold text-white"><?php echo $stats['total_revenue']; ?> ₽</p>
        </div>
    </div>
    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <div>
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold text-white">Последние пользователи</h2>
                <a href="/admin/users.php" class="text-zinc-400 hover:text-white transition-colors">
                    Все пользователи
                </a>
            </div>
            
            <div class="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
                <table class="w-full">
                    <thead class="bg-zinc-800">
                        <tr>
                            <th class="py-3 px-4 text-left text-white">Имя</th>
                            <th class="py-3 px-4 text-left text-white">Email</th>
                            <th class="py-3 px-4 text-center text-white">Роль</th>
                            <th class="py-3 px-4 text-center text-white">Дата регистрации</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($latestUsers)): ?>
                            <tr class="border-t border-zinc-800">
                                <td colspan="4" class="py-4 px-4 text-center text-zinc-400">Нет данных</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($latestUsers as $user): ?>
                                <tr class="border-t border-zinc-800">
                                    <td class="py-3 px-4 text-white"><?php echo $user['name']; ?></td>
                                    <td class="py-3 px-4 text-zinc-400"><?php echo $user['email']; ?></td>
                                    <td class="py-3 px-4 text-center">
                                        <?php if ($user['role'] === 'admin'): ?>
                                            <span class="inline-block px-2 py-1 bg-red-900/30 text-red-200 rounded text-xs">Админ</span>
                                        <?php elseif ($user['role'] === 'seller'): ?>
                                            <span class="inline-block px-2 py-1 bg-blue-900/30 text-blue-200 rounded text-xs">Продавец</span>
                                        <?php else: ?>
                                            <span class="inline-block px-2 py-1 bg-zinc-800 text-zinc-300 rounded text-xs">Покупатель</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3 px-4 text-center text-zinc-400">
                                        <?php echo date('d.m.Y', strtotime($user['created_at'] ?? 'now')); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div>
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold text-white">Последние заказы</h2>
                <a href="/admin/orders.php" class="text-zinc-400 hover:text-white transition-colors">
                    Все заказы
                </a>
            </div>
            
            <div class="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
                <table class="w-full">
                    <thead class="bg-zinc-800">
                        <tr>
                            <th class="py-3 px-4 text-left text-white">ID</th>
                            <th class="py-3 px-4 text-left text-white">Пользователь</th>
                            <th class="py-3 px-4 text-center text-white">Сумма</th>
                            <th class="py-3 px-4 text-center text-white">Статус</th>
                            <th class="py-3 px-4 text-center text-white">Дата</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($latestOrders)): ?>
                            <tr class="border-t border-zinc-800">
                                <td colspan="5" class="py-4 px-4 text-center text-zinc-400">Нет данных</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($latestOrders as $order): ?>
                                <tr class="border-t border-zinc-800">
                                    <td class="py-3 px-4 text-white">#<?php echo $order['id']; ?></td>
                                    <td class="py-3 px-4 text-white"><?php echo $order['user_name']; ?></td>
                                    <td class="py-3 px-4 text-center text-white"><?php echo $order['total_price']; ?> ₽</td>
                                    <td class="py-3 px-4 text-center">
                                        <?php 
                                        switch ($order['status']) {
                                            case 'pending':
                                                echo '<span class="inline-block px-2 py-1 bg-yellow-900/30 text-yellow-200 rounded text-xs">Ожидает оплаты</span>';
                                                break;
                                            case 'paid':
                                                echo '<span class="inline-block px-2 py-1 bg-blue-900/30 text-blue-200 rounded text-xs">Оплачен</span>';
                                                break;
                                            case 'completed':
                                                echo '<span class="inline-block px-2 py-1 bg-green-900/30 text-green-200 rounded text-xs">Выполнен</span>';
                                                break;
                                            case 'cancelled':
                                                echo '<span class="inline-block px-2 py-1 bg-red-900/30 text-red-200 rounded text-xs">Отменен</span>';
                                                break;
                                            default:
                                                echo '<span class="inline-block px-2 py-1 bg-zinc-800 text-zinc-300 rounded text-xs">В обработке</span>';
                                        }
                                        ?>
                                    </td>
                                    <td class="py-3 px-4 text-center text-zinc-400">
                                        <?php echo date('d.m.Y', strtotime($order['created_at'] ?? 'now')); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <div class="grid grid-cols-1 gap-6">
        <div class="bg-zinc-900 border border-zinc-800 rounded-lg p-6">
            <h2 class="text-xl font-bold mb-4 text-white">Быстрые действия</h2>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <a href="/admin/add-category.php" class="bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg p-4 flex items-center transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                    </svg>
                    Добавить категорию
                </a>
                
                <a href="/admin/users.php" class="bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg p-4 flex items-center transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                    </svg>
                    Управление пользователями
                </a>
                
                <a href="/admin/products.php" class="bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg p-4 flex items-center transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                    </svg>
                    Управление товарами
                </a>
                
                <a href="/admin/chats.php" class="bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg p-4 flex items-center transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                    </svg>
                    Чаты поддержки
                </a>
            </div>
        </div>
    </div>
</div>

<?php
// Подключаем подвал сайта
include '../includes/footer.php';
?>

