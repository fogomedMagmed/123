<?php
// Начинаем сессию
session_start();

// Подключаем файл с функциями
require_once '../includes/functions.php';

// Если пользователь не авторизован или не является администратором, перенаправляем на главную
if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../index.php');
    exit;
}

// Подключаемся к базе данных
$pdo = require '../config/database.php';

// Получаем всех пользователей
$users = [];
try {
    if ($pdo instanceof PDO) {
        $stmt = $pdo->query("SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC");
        $users = $stmt->fetchAll();
    }
} catch (PDOException $e) {
    // В случае ошибки оставляем пустой массив
}

// Подключаем шапку сайта
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="mb-4">
        <a href="/admin/dashboard.php" class="text-zinc-400 hover:text-white transition-colors">
            ← Назад к панели администратора
        </a>
    </div>
    
    <h1 class="text-3xl font-bold mb-6 text-white">Управление пользователями</h1>
    
    <div class="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
        <table class="w-full">
            <thead class="bg-zinc-800">
                <tr>
                    <th class="py-3 px-4 text-left text-white">ID</th>
                    <th class="py-3 px-4 text-left text-white">Имя</th>
                    <th class="py-3 px-4 text-left text-white">Email</th>
                    <th class="py-3 px-4 text-center text-white">Роль</th>
                    <th class="py-3 px-4 text-center text-white">Дата регистрации</th>
                    <th class="py-3 px-4 text-center text-white">Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users)): ?>
                    <tr class="border-t border-zinc-800">
                        <td colspan="6" class="py-4 px-4 text-center text-zinc-400">Нет данных</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($users as $user): ?>
                        <tr class="border-t border-zinc-800">
                            <td class="py-3 px-4 text-white"><?php echo $user['id']; ?></td>
                            <td class="py-3 px-4 text-white"><?php echo $user['name']; ?></td>
                            <td class="py-3 px-4 text-zinc-400"><?php echo $user['email']; ?></td>
                            <td class="py-3 px-4 text-center">
                                <?php if ($user['role'] === 'admin'): ?>
                                    <span class="inline-block px-2 py-1 bg-red-900/30 text-red-200 rounded text-xs">Администратор</span>
                                <?php elseif ($user['role'] === 'seller'): ?>
                                    <span class="inline-block px-2 py-1 bg-blue-900/30 text-blue-200 rounded text-xs">Продавец</span>
                                <?php else: ?>
                                    <span class="inline-block px-2 py-1 bg-zinc-800 text-zinc-300 rounded text-xs">Покупатель</span>
                                <?php endif; ?>
                            </td>
                            <td class="py-3 px-4 text-center text-zinc-400">
                                <?php echo date('d.m.Y', strtotime($user['created_at'])); ?>
                            </td>
                            <td class="py-3 px-4 text-center">
                                <div class="flex justify-center space-x-2">
                                    <a href="/admin/edit-user.php?id=<?php echo $user['id']; ?>" class="text-blue-400 hover:text-blue-300">
                                        Редактировать
                                    </a>
                                    <?php if ($user['id'] != $_SESSION['user']['id']): ?>
                                        <a href="/admin/delete-user.php?id=<?php echo $user['id']; ?>" class="text-red-400 hover:text-red-300" onclick="return confirm('Вы уверены, что хотите удалить этого пользователя?')">
                                            Удалить
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
// Подключаем подвал сайта
include '../includes/footer.php';
?>

