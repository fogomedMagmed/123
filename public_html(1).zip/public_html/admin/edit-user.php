<?php
// Начинаем сессию
session_start();

// Подключаем файл с функциями
require_once '../includes/functions.php';

// Если пользователь не авторизован или не является администратором, перенаправляем на главную
if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../index.php');
    exit;
}

// Подключаемся к базе данных
$pdo = require '../config/database.php';

// Получаем ID пользователя из URL
$userId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Проверяем, что ID пользователя передан
if ($userId === 0) {
    $_SESSION['admin_error'] = 'Не указан ID пользователя';
    header('Location: users.php');
    exit;
}

// Получаем данные пользователя
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) {
    $_SESSION['admin_error'] = 'Пользователь не найден';
    header('Location: users.php');
    exit;
}

$error = '';
$success = '';

// Обработка формы обновления пользователя
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $role = $_POST['role'] ?? 'buyer';
    $newPassword = $_POST['new_password'] ?? '';
    
    // Проверяем, что email не занят другим пользователем
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
    $stmt->execute([$email, $userId]);
    if ($stmt->fetch()) {
        $error = 'Пользователь с таким email уже существует';
    } else {
        try {
            // Начинаем транзакцию
            $pdo->beginTransaction();
            
            // Если указан новый пароль, обновляем его
            if (!empty($newPassword)) {
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, role = ?, password = ? WHERE id = ?");
                $stmt->execute([$name, $email, $role, $hashedPassword, $userId]);
            } else {
                $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, role = ? WHERE id = ?");
                $stmt->execute([$name, $email, $role, $userId]);
            }
            
            // Завершаем транзакцию
            $pdo->commit();
            
            $success = 'Пользователь успешно обновлен';
            
            // Обновляем данные пользователя
            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
        } catch (PDOException $e) {
            // Откатываем транзакцию в случае ошибки
            $pdo->rollBack();
            $error = 'Ошибка при обновлении пользователя: ' . $e->getMessage();
        }
    }
}

// Подключаем шапку сайта
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="mb-4">
        <a href="/admin/users.php" class="text-zinc-400 hover:text-white transition-colors">
            ← Назад к списку пользователей
        </a>
    </div>
    
    <div class="bg-zinc-900 border border-zinc-800 rounded-lg p-6 max-w-lg mx-auto">
        <h1 class="text-2xl font-bold mb-6 text-center text-white">Редактирование пользователя</h1>
        
        <?php if ($error): ?>
            <div class="bg-red-900/30 border border-red-800 text-red-200 px-4 py-3 rounded mb-4">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="bg-green-900/30 border border-green-800 text-green-200 px-4 py-3 rounded mb-4">
                <?php echo $success; ?>
            </div>
        <?php endif; ?>
        
        <form method="post" action="" class="space-y-4">
            <div class="space-y-2">
                <label for="name" class="text-zinc-300">Имя</label>
                <input
                    id="name"
                    name="name"
                    type="text"
                    value="<?php echo htmlspecialchars($user['name']); ?>"
                    required
                    class="w-full bg-zinc-800 border border-zinc-700 rounded p-2 text-white"
                >
            </div>
            
            <div class="space-y-2">
                <label for="email" class="text-zinc-300">Email</label>
                <input
                    id="email"
                    name="email"
                    type="email"
                    value="<?php echo htmlspecialchars($user['email']); ?>"
                    required
                    class="w-full bg-zinc-800 border border-zinc-700 rounded p-2 text-white"
                >
            </div>
            
            <div class="space-y-2">
                <label for="role" class="text-zinc-300">Роль</label>
                <select
                    id="role"
                    name="role"
                    class="w-full bg-zinc-800 border border-zinc-700 rounded p-2 text-white"
                >
                    <option value="buyer" <?php echo $user['role'] === 'buyer' ? 'selected' : ''; ?>>Покупатель</option>
                    <option value="seller" <?php echo $user['role'] === 'seller' ? 'selected' : ''; ?>>Продавец</option>
                    <option value="admin" <?php echo $user['role'] === 'admin' ? 'selected' : ''; ?>>Администратор</option>
                </select>
            </div>
            
            <div class="space-y-2">
                <label for="new_password" class="text-zinc-300">Новый пароль (оставьте пустым, чтобы не менять)</label>
                <input
                    id="new_password"
                    name="new_password"
                    type="password"
                    class="w-full bg-zinc-800 border border-zinc-700 rounded p-2 text-white"
                >
            </div>
            
            <div class="flex justify-between">
                <a href="/admin/users.php" class="px-4 py-2 bg-zinc-700 hover:bg-zinc-600 text-white rounded-md transition-colors">
                    Отмена
                </a>
                <button type="submit" class="px-4 py-2 bg-white hover:bg-gray-200 text-black rounded-md transition-colors">
                    Сохранить
                </button>
            </div>
        </form>
    </div>
</div>

<?php
// Подключаем подвал сайта
include '../includes/footer.php';
?>

