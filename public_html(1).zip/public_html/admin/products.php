<?php
// Начинаем сессию
session_start();

// Подключаем файл с функциями
require_once '../includes/functions.php';

// Если пользователь не авторизован или не является администратором, перенаправляем на главную
if (!isLoggedIn() || !isAdmin()) {
    header('Location: ../index.php');
    exit;
}

// Подключаемся к базе данных
$pdo = require '../config/database.php';

// Получаем все товары
$products = [];
try {
    if ($pdo instanceof PDO) {
        $stmt = $pdo->query("
            SELECT p.*, u.name as seller_name, c.name as category_name
            FROM products p
            JOIN users u ON p.seller_id = u.id
            JOIN categories c ON p.category_id = c.id
            ORDER BY p.created_at DESC
        ");
        $products = $stmt->fetchAll();
    }
} catch (PDOException $e) {
    // В случае ошибки оставляем пустой массив
}

// Подключаем шапку сайта
include '../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="mb-4">
        <a href="/admin/dashboard.php" class="text-zinc-400 hover:text-white transition-colors">
            ← Назад к панели администратора
        </a>
    </div>
    
    <h1 class="text-3xl font-bold mb-6 text-white">Управление товарами</h1>
    
    <div class="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
        <table class="w-full">
            <thead class="bg-zinc-800">
                <tr>
                    <th class="py-3 px-4 text-left text-white">ID</th>
                    <th class="py-3 px-4 text-left text-white">Товар</th>
                    <th class="py-3 px-4 text-center text-white">Категория</th>
                    <th class="py-3 px-4 text-center text-white">Продавец</th>
                    <th class="py-3 px-4 text-center text-white">Цена</th>
                    <th class="py-3 px-4 text-center text-white">Статус</th>
                    <th class="py-3 px-4 text-center text-white">Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($products)): ?>
                    <tr class="border-t border-zinc-800">
                        <td colspan="7" class="py-4 px-4 text-center text-zinc-400">Нет данных</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($products as $product): ?>
                        <tr class="border-t border-zinc-800">
                            <td class="py-3 px-4 text-white"><?php echo $product['id']; ?></td>
                            <td class="py-3 px-4">
                                <div class="flex items-center">
                                    <img src="../<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="w-12 h-12 object-cover rounded mr-3">
                                    <div>
                                        <h3 class="text-white font-medium"><?php echo $product['name']; ?></h3>
                                        <p class="text-zinc-400 text-sm truncate max-w-xs"><?php echo $product['description']; ?></p>
                                    </div>
                                </div>
                            </td>
                            <td class="py-3 px-4 text-center text-white"><?php echo $product['category_name']; ?></td>
                            <td class="py-3 px-4 text-center text-white"><?php echo $product['seller_name']; ?></td>
                            <td class="py-3 px-4 text-center text-white"><?php echo $product['price']; ?> ₽</td>
                            <td class="py-3 px-4 text-center">
                                <?php if ($product['status'] === 'active'): ?>
                                    <span class="inline-block px-2 py-1 bg-green-900/30 text-green-200 rounded text-xs">Активен</span>
                                <?php elseif ($product['status'] === 'inactive'): ?>
                                    <span class="inline-block px-2 py-1 bg-red-900/30 text-red-200 rounded text-xs">Неактивен</span>
                                <?php else: ?>
                                    <span class="inline-block px-2 py-1 bg-blue-900/30 text-blue-200 rounded text-xs">Продан</span>
                                <?php endif; ?>
                            </td>
                            <td class="py-3 px-4 text-center">
                                <div class="flex justify-center space-x-2">
                                    <a href="/product.php?id=<?php echo $product['id']; ?>" class="text-blue-400 hover:text-blue-300">
                                        Просмотр
                                    </a>
                                    <a href="/admin/edit-product.php?id=<?php echo $product['id']; ?>" class="text-blue-400 hover:text-blue-300">
                                        Редактировать
                                    </a>
                                    <a href="/admin/delete-product.php?id=<?php echo $product['id']; ?>" class="text-red-400 hover:text-red-300" onclick="return confirm('Вы уверены, что хотите удалить этот товар?')">
                                        Удалить
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
// Подключаем подвал сайта
include '../includes/footer.php';
?>

