<?php
// Перенаправляем на панель продавца
header('Location: dashboard.php');
exit;
?>

