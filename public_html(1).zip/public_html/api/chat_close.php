<?php
// Начинаем сессию
session_start();

// Проверяем, авторизован ли пользователь
if (!isset($_SESSION['user'])) {
  header('Location: /login.php');
  exit;
}

// Проверяем, переданы ли необходимые параметры
if (!isset($_POST['chat_id'])) {
  header('Location: /chat.php');
  exit;
}

// Получаем параметры
$chatId = (int)$_POST['chat_id'];
$userId = $_SESSION['user']['id'];
$deleteCompletely = isset($_POST['delete_completely']) && $_POST['delete_completely'] == 1;

// Подключаемся к базе данных
require_once __DIR__ . '/../config/database.php';

// Проверяем, принадлежит ли чат пользователю или является ли пользователь оператором
$isOwner = false;
$isOperator = false;

// Проверяем, принадлежит ли чат пользователю
$stmt = $pdo->prepare("SELECT * FROM chats WHERE id = ? AND user_id = ?");
$stmt->execute([$chatId, $userId]);
$chat = $stmt->fetch(PDO::FETCH_ASSOC);

if ($chat) {
  $isOwner = true;
}

// Проверяем, является ли пользователь оператором
if ($_SESSION['user']['role'] === 'admin') {
  $isOperator = true;
}

// Если пользователь не владелец чата и не оператор, перенаправляем на страницу чата
if (!$isOwner && !$isOperator) {
  header('Location: /chat.php');
  exit;
}

// Если нужно полностью удалить чат
if ($deleteCompletely) {
   try {
       // Начинаем транзакцию
       $pdo->beginTransaction();
       
       // Удаляем все сообщения чата
       $stmt = $pdo->prepare("DELETE FROM chat_messages WHERE chat_id = ?");
       $stmt->execute([$chatId]);
       
       // Удаляем назначения чата операторам
       $stmt = $pdo->prepare("DELETE FROM chat_assignments WHERE chat_id = ?");
       $stmt->execute([$chatId]);
       
       // Удаляем контекст чата
       $stmt = $pdo->prepare("DELETE FROM chat_context WHERE chat_id = ?");
       $stmt->execute([$chatId]);
       
       // Удаляем сам чат
       $stmt = $pdo->prepare("DELETE FROM chats WHERE id = ?");
       $stmt->execute([$chatId]);
       
       // Завершаем транзакцию
       $pdo->commit();
       
       // Перенаправляем на страницу чата
       header('Location: /chat.php');
       exit;
   } catch (PDOException $e) {
       // Откатываем транзакцию в случае ошибки
       $pdo->rollBack();
       
       // Перенаправляем на страницу чата с ошибкой
       header('Location: /chat.php?error=delete_failed');
       exit;
   }
} else {
   // Просто закрываем чат
   $stmt = $pdo->prepare("UPDATE chats SET status = 'closed' WHERE id = ?");
   $stmt->execute([$chatId]);

   // Добавляем системное сообщение о закрытии чата
   $stmt = $pdo->prepare("INSERT INTO chat_messages (chat_id, sender_type, message) VALUES (?, 'bot', 'Чат закрыт.')");
   $stmt->execute([$chatId]);

   // Перенаправляем на страницу чата
   header('Location: /chat.php');
   exit;
}