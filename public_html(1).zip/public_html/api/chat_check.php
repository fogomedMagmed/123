<?php
// Начинаем сессию
session_start();

// Проверяем, авторизован ли пользователь
if (!isset($_SESSION['user'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Необходимо авторизоваться']);
    exit;
}

// Проверяем, переданы ли необходимые параметры
if (!isset($_GET['chat_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Не указан ID чата']);
    exit;
}

// Получаем параметры
$chatId = (int)$_GET['chat_id'];
$lastMessageId = isset($_GET['last_message_id']) ? (int)$_GET['last_message_id'] : 0;
$userId = $_SESSION['user']['id'];

// Подключаемся к базе данных
require_once __DIR__ . '/../config/database.php';

// Проверяем, принадлежит ли чат пользователю
$stmt = $pdo->prepare("SELECT * FROM chats WHERE id = ? AND user_id = ?");
$stmt->execute([$chatId, $userId]);
$chat = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$chat) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Чат не найден или не принадлежит пользователю']);
    exit;
}

// Получаем новые сообщения
$stmt = $pdo->prepare("SELECT * FROM chat_messages WHERE chat_id = ? AND id > ? ORDER BY created_at ASC");
$stmt->execute([$chatId, $lastMessageId]);
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Отмечаем сообщения как прочитанные
if (!empty($messages)) {
    $stmt = $pdo->prepare("UPDATE chat_messages SET is_read = 1 WHERE chat_id = ? AND sender_type != 'user' AND is_read = 0");
    $stmt->execute([$chatId]);
}

// Проверяем, изменился ли статус чата
$statusChanged = false;
$stmt = $pdo->prepare("SELECT status FROM chats WHERE id = ?");
$stmt->execute([$chatId]);
$currentStatus = $stmt->fetchColumn();

if ($currentStatus !== $chat['status']) {
    $statusChanged = true;
}

// Возвращаем результат
header('Content-Type: application/json');
echo json_encode([
    'success' => true,
    'messages' => $messages,
    'statusChanged' => $statusChanged
]);
exit;

