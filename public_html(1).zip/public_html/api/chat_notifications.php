<?php
// Начинаем сессию
session_start();

// Проверяем, авторизован ли пользователь и является ли он администратором
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
   header('Content-Type: application/json');
   echo json_encode(['success' => false, 'error' => 'Доступ запрещен']);
   exit;
}

// Подключаемся к базе данных
require_once __DIR__ . '/../config/database.php';

// Получаем количество чатов, ожидающих оператора
$stmt = $pdo->prepare("SELECT COUNT(*) FROM chats WHERE status = 'waiting_for_operator'");
$stmt->execute();
$waitingChatsCount = $stmt->fetchColumn();

// Получаем количество непрочитанных сообщений от пользователей
$stmt = $pdo->prepare("
   SELECT COUNT(*) FROM chat_messages 
   WHERE sender_type = 'user' AND is_read = 0
");
$stmt->execute();
$unreadMessagesCount = $stmt->fetchColumn();

// Возвращаем результат
header('Content-Type: application/json');
echo json_encode([
   'success' => true,
   'waitingChatsCount' => $waitingChatsCount,
   'unreadMessagesCount' => $unreadMessagesCount,
   'totalNotifications' => $waitingChatsCount + $unreadMessagesCount
]);
exit;