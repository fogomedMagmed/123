<?php
// Начинаем сессию
session_start();

// Проверяем, авторизован ли пользователь и является ли он администратором
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
   header('Content-Type: application/json');
   echo json_encode(['success' => false, 'error' => 'Доступ запрещен']);
   exit;
}

// Проверяем, переданы ли необходимые параметры
if (!isset($_POST['chat_id']) || !isset($_POST['message'])) {
   header('Content-Type: application/json');
   echo json_encode(['success' => false, 'error' => 'Не указаны обязательные параметры']);
   exit;
}

// Получаем параметры
$chatId = (int)$_POST['chat_id'];
$message = trim($_POST['message']);
$operatorId = $_SESSION['user']['id'];

// Проверяем, не пустое ли сообщение
if (empty($message)) {
   header('Content-Type: application/json');
   echo json_encode(['success' => false, 'error' => 'Сообщение не может быть пустым']);
   exit;
}

// Подключаемся к базе данных
require_once __DIR__ . '/../config/database.php';

// Проверяем, существует ли чат
$stmt = $pdo->prepare("SELECT * FROM chats WHERE id = ?");
$stmt->execute([$chatId]);
$chat = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$chat) {
   header('Content-Type: application/json');
   echo json_encode(['success' => false, 'error' => 'Чат не найден']);
   exit;
}

// Проверяем, не закрыт ли чат
if ($chat['status'] === 'closed') {
   header('Content-Type: application/json');
   echo json_encode(['success' => false, 'error' => 'Чат закрыт']);
   exit;
}

// Если чат в режиме ожидания оператора, меняем его статус на активный
if ($chat['status'] === 'waiting_for_operator') {
   $stmt = $pdo->prepare("UPDATE chats SET status = 'active' WHERE id = ?");
   $stmt->execute([$chatId]);
}

// Сохраняем сообщение оператора
$stmt = $pdo->prepare("INSERT INTO chat_messages (chat_id, sender_type, sender_id, message) VALUES (?, 'operator', ?, ?)");
$stmt->execute([$chatId, $operatorId, $message]);
$messageId = $pdo->lastInsertId();

// Обновляем время последнего сообщения в чате
$stmt = $pdo->prepare("UPDATE chats SET updated_at = NOW() WHERE id = ?");
$stmt->execute([$chatId]);

// Возвращаем успешный результат
header('Content-Type: application/json');
echo json_encode([
   'success' => true,
   'messageId' => $messageId
]);
exit;