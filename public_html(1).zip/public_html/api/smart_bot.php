<?php
/**
 * Умный бот для обработки сообщений пользователей
 */
class SmartBot {
    private $pdo;
    private $chatId;
    private $userId;
    private $message;
    private $context;
    private $previousMessages;
    
    /**
     * Конструктор класса
     * 
     * @param PDO $pdo Объект PDO для работы с базой данных
     * @param int $chatId ID чата
     * @param int $userId ID пользователя
     * @param string $message Сообщение пользователя
     */
    public function __construct($pdo, $chatId, $userId, $message) {
        $this->pdo = $pdo;
        $this->chatId = $chatId;
        $this->userId = $userId;
        $this->message = mb_strtolower(trim($message));
        $this->context = $this->getContext();
        $this->previousMessages = $this->getPreviousMessages(3);
    }
    
    /**
     * Получение контекста чата
     * 
     * @return array Контекст чата
     */
    private function getContext() {
        $stmt = $this->pdo->prepare("SELECT context_data FROM chat_context WHERE chat_id = ? ORDER BY updated_at DESC LIMIT 1");
        $stmt->execute([$this->chatId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result && $result['context_data']) {
            return json_decode($result['context_data'], true);
        }
        
        return [];
    }
    
    /**
     * Сохранение контекста чата
     * 
     * @param array $context Контекст чата
     */
    private function saveContext($context) {
        // Проверяем, существует ли уже контекст для этого чата
        $stmt = $this->pdo->prepare("SELECT id FROM chat_context WHERE chat_id = ?");
        $stmt->execute([$this->chatId]);
        $existingContext = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existingContext) {
            // Обновляем существующий контекст
            $stmt = $this->pdo->prepare("UPDATE chat_context SET context_data = ?, updated_at = NOW() WHERE chat_id = ?");
            $stmt->execute([json_encode($context), $this->chatId]);
        } else {
            // Создаем новый контекст
            $stmt = $this->pdo->prepare("INSERT INTO chat_context (chat_id, context_data) VALUES (?, ?)");
            $stmt->execute([$this->chatId, json_encode($context)]);
        }
    }
    
    /**
     * Получение информации о пользователе
     * 
     * @return array Информация о пользователе
     */
    private function getUserInfo() {
        $stmt = $this->pdo->prepare("SELECT name, email, role FROM users WHERE id = ?");
        $stmt->execute([$this->userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Получение предыдущих сообщений чата
     * 
     * @param int $limit Количество сообщений
     * @return array Предыдущие сообщения
     */
    private function getPreviousMessages($limit = 5) {
        $stmt = $this->pdo->prepare("
            SELECT sender_type, message 
            FROM chat_messages 
            WHERE chat_id = ? 
            ORDER BY created_at DESC 
            LIMIT ?
        ");
        $stmt->execute([$this->chatId, $limit]);
        return array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
    
    /**
     * Анализ контекста разговора на основе предыдущих сообщений
     * 
     * @return string|null Определенный контекст или null
     */
    private function analyzeConversationContext() {
        // Если есть предыдущие сообщения, анализируем их
        if (!empty($this->previousMessages)) {
            $combinedMessages = '';
            foreach ($this->previousMessages as $msg) {
                if ($msg['sender_type'] === 'user') {
                    $combinedMessages .= ' ' . mb_strtolower($msg['message']);
                }
            }
            
            // Проверяем наличие технических терминов в предыдущих сообщениях
            $technicalTerms = ['ошибка', 'проблема', 'не работает', 'не могу', 'не удается', 'баг', 'глюк'];
            foreach ($technicalTerms as $term) {
                if (strpos($combinedMessages, $term) !== false) {
                    return 'technical_issue';
                }
            }
            
            // Проверяем наличие терминов, связанных с товарами
            $productTerms = ['товар', 'продукт', 'предмет', 'аккаунт', 'валюта'];
            foreach ($productTerms as $term) {
                if (strpos($combinedMessages, $term) !== false) {
                    return 'product_related';
                }
            }
            
            // Проверяем наличие терминов, связанных с оплатой
            $paymentTerms = ['оплата', 'платеж', 'деньги', 'карта', 'счет'];
            foreach ($paymentTerms as $term) {
                if (strpos($combinedMessages, $term) !== false) {
                    return 'payment_related';
                }
            }
        }
        
        return null;
    }
    
    /**
     * Определение темы сообщения
     * 
     * @return string Тема сообщения
     */
    private function determineMessageTopic() {
        // Технические проблемы
        $technicalTerms = [
            'ошибка', 'проблема', 'не работает', 'не могу', 'не удается', 'баг', 'глюк', 
            'сбой', 'не получается', 'не проходит', 'не загружается'
        ];
        
        foreach ($technicalTerms as $term) {
            if (strpos($this->message, $term) !== false) {
                // Определяем тип технической проблемы
                if (strpos($this->message, 'добавить товар') !== false || 
                    strpos($this->message, 'добавлени') !== false ||
                    strpos($this->message, 'товар уже') !== false) {
                    return 'technical_product_add';
                }
                
                if (strpos($this->message, 'регистрац') !== false || 
                    strpos($this->message, 'создать аккаунт') !== false) {
                    return 'technical_registration';
                }
                
                if (strpos($this->message, 'оплат') !== false || 
                    strpos($this->message, 'платеж') !== false) {
                    return 'technical_payment';
                }
                
                if (strpos($this->message, 'вход') !== false || 
                    strpos($this->message, 'авторизац') !== false ||
                    strpos($this->message, 'войти') !== false) {
                    return 'technical_login';
                }
                
                if (strpos($this->message, 'загруз') !== false || 
                    strpos($this->message, 'файл') !== false ||
                    strpos($this->message, 'изображен') !== false) {
                    return 'technical_upload';
                }
                
                return 'technical_general';
            }
        }
        
        // Вопросы о товарах
        $productTerms = ['товар', 'продукт', 'предмет', 'аккаунт', 'валюта', 'игра', 'купить', 'продать'];
        foreach ($productTerms as $term) {
            if (strpos($this->message, $term) !== false) {
                return 'product_related';
            }
        }
        
        // Вопросы об оплате
        $paymentTerms = ['оплата', 'платеж', 'деньги', 'карта', 'счет', 'цена', 'стоимость'];
        foreach ($paymentTerms as $term) {
            if (strpos($this->message, $term) !== false) {
                return 'payment_related';
            }
        }
        
        // Общие вопросы
        return 'general';
    }
    
    /**
     * Поиск наиболее подходящего ответа
     * 
     * @return array|null Найденный ответ или null
     */
    private function findBestResponse() {
        // Сначала проверяем контекст
        if (!empty($this->context['last_intent'])) {
            // Если ожидаем конкретную информацию
            if (!empty($this->context['awaiting'])) {
                return $this->handleAwaitingContext();
            }
            
            // Проверяем, есть ли ответ, требующий этот контекст
            $stmt = $this->pdo->prepare("
                SELECT * FROM bot_responses 
                WHERE requires_context = 1 
                AND JSON_CONTAINS(sets_context, ?, '$.last_intent')
                LIMIT 1
            ");
            $stmt->execute([json_encode($this->context['last_intent'])]);
            $contextResponse = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($contextResponse) {
                return $contextResponse;
            }
        }
        
        // Определяем тему сообщения
        $messageTopic = $this->determineMessageTopic();
        
        // Если это техническая проблема, ищем соответствующий ответ
        if (strpos($messageTopic, 'technical_') === 0) {
            $keyword = '';
            
            switch ($messageTopic) {
                case 'technical_product_add':
                    $keyword = 'ошибка_добавление_товара';
                    break;
                case 'technical_registration':
                    $keyword = 'ошибка_регистрация';
                    break;
                case 'technical_payment':
                    $keyword = 'ошибка_оплата';
                    break;
                case 'technical_login':
                    $keyword = 'ошибка_авторизация';
                    break;
                case 'technical_upload':
                    $keyword = 'ошибка_загрузка';
                    break;
                default:
                    $keyword = 'ошибка_общая';
            }
            
            $stmt = $this->pdo->prepare("SELECT * FROM bot_responses WHERE keyword = ?");
            $stmt->execute([$keyword]);
            $response = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($response) {
                return $response;
            }
        }
        
        // Анализируем контекст разговора
        $conversationContext = $this->analyzeConversationContext();
        
        // Если определили контекст разговора, ищем ответы в соответствующей категории
        if ($conversationContext) {
            $stmt = $this->pdo->prepare("SELECT * FROM bot_responses WHERE category = ? ORDER BY id ASC");
            $stmt->execute([$conversationContext]);
            $categoryResponses = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (!empty($categoryResponses)) {
                $bestMatch = null;
                $bestScore = 0;
                
                foreach ($categoryResponses as $response) {
                    $score = 0;
                    
                    // Проверяем прямое совпадение с ключевым словом
                    if (strpos($this->message, $response['keyword']) !== false) {
                        $score += 5;
                    }
                    
                    // Проверяем совпадение с шаблонами
                    if ($response['patterns']) {
                        $patterns = json_decode($response['patterns'], true);
                        foreach ($patterns as $pattern) {
                            if (strpos($this->message, $pattern) !== false) {
                                $score += 3;
                            }
                        }
                    }
                    
                    // Если это лучшее совпадение, сохраняем его
                    if ($score > $bestScore) {
                        $bestScore = $score;
                        $bestMatch = $response;
                    }
                }
                
                // Если нашли совпадение с достаточным счетом
                if ($bestScore >= 3) {
                    return $bestMatch;
                }
            }
        }
        
        // Ищем ответ по ключевым словам и шаблонам
        $stmt = $this->pdo->prepare("SELECT * FROM bot_responses ORDER BY id ASC");
        $stmt->execute();
        $responses = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $bestMatch = null;
        $bestScore = 0;
        
        foreach ($responses as $response) {
            $score = 0;
            
            // Проверяем прямое совпадение с ключевым словом
            if (strpos($this->message, $response['keyword']) !== false) {
                $score += 5;
            }
            
            // Проверяем совпадение с шаблонами
            if ($response['patterns']) {
                $patterns = json_decode($response['patterns'], true);
                foreach ($patterns as $pattern) {
                    if (strpos($this->message, $pattern) !== false) {
                        $score += 3;
                    }
                }
            }
            
            // Если это лучшее совпадение, сохраняем его
            if ($score > $bestScore) {
                $bestScore = $score;
                $bestMatch = $response;
            }
        }
        
        // Если нашли совпадение с достаточным счетом
        if ($bestScore >= 3) {
            return $bestMatch;
        }
        
        // Если не нашли подходящего ответа, возвращаем общий ответ
        return [
            'response' => "Извините, я не совсем понял ваш вопрос. Вы можете уточнить, что именно вас интересует? Я могу помочь с информацией о заказах, товарах, оплате, регистрации и других вопросах, связанных с GameMarket.",
            'sets_context' => json_encode(['last_intent' => 'unclear'])
        ];
    }
    
    /**
     * Обработка контекста ожидания
     * 
     * @return array Ответ бота
     */
    private function handleAwaitingContext() {
        $awaiting = $this->context['awaiting'];
        $lastIntent = $this->context['last_intent'];
        
        switch ($awaiting) {
            case 'error_details':
                // Пользователь предоставил детали технической проблемы
                return [
                    'response' => "Спасибо за подробное описание проблемы. Я передал эту информацию нашим техническим специалистам, и они займутся решением этой проблемы в ближайшее время. Если у вас возникнут дополнительные вопросы или проблемы, пожалуйста, сообщите мне. Приносим извинения за неудобства.",
                    'sets_context' => json_encode(['last_intent' => 'technical_issue_reported'])
                ];
                break;
                
            case 'order_number':
                // Проверяем, похоже ли сообщение на номер заказа
                if (preg_match('/\d+/', $this->message, $matches)) {
                    return [
                        'response' => "Спасибо за предоставленный номер заказа. Я проверил информацию о заказе #{$matches[0]}. Ваш заказ находится в обработке и будет доставлен в ближайшее время. Если у вас есть еще вопросы по этому заказу, дайте мне знать.",
                        'sets_context' => json_encode(['last_intent' => 'order_details', 'order_number' => $matches[0]])
                    ];
                } else {
                    return [
                        'response' => "Пожалуйста, укажите номер вашего заказа, чтобы я мог предоставить информацию о нем. Номер заказа обычно начинается с # и содержит цифры.",
                        'sets_context' => json_encode(['last_intent' => $lastIntent, 'awaiting' => $awaiting])
                    ];
                }
                break;
                
            case 'order_details':
                // Пользователь предоставил детали проблемы с заказом
                return [
                    'response' => "Спасибо за подробное описание проблемы с заказом. Я передал информацию нашим специалистам, и они свяжутся с вами в ближайшее время для решения этой проблемы. Если у вас есть дополнительная информация, пожалуйста, сообщите.",
                    'sets_context' => json_encode(['last_intent' => 'order_problem_reported'])
                ];
                break;
                
            case 'payment_details':
                // Пользователь предоставил детали проблемы с оплатой
                return [
                    'response' => "Благодарю за информацию о проблеме с оплатой. Наш финансовый отдел рассмотрит ваш случай в течение 24 часов. Вы получите уведомление на email, когда проблема будет решена. Если у вас есть чек или скриншот платежа, пожалуйста, отправьте его на support@gamemarket.ru с указанием вашего ID пользователя.",
                    'sets_context' => json_encode(['last_intent' => 'payment_problem_reported'])
                ];
                break;
                
            case 'product_interest':
                // Пользователь указал, какой товар его интересует
                return [
                    'response' => "Я понял, что вас интересуют товары, связанные с \"{$this->message}\". На GameMarket есть множество таких товаров. Вы можете найти их, используя поиск на главной странице или перейдя в соответствующую категорию. Также вы можете использовать фильтры для уточнения результатов поиска. Хотите, чтобы я рассказал подробнее о конкретной категории товаров?",
                    'sets_context' => json_encode(['last_intent' => 'product_recommendation', 'product_interest' => $this->message])
                ];
                break;
                
            case 'selling_question':
                // Пользователь задал вопрос о продаже товаров
                return [
                    'response' => "Спасибо за ваш вопрос о продаже товаров. Процесс продажи на GameMarket довольно прост. После регистрации как продавец, вы можете добавлять товары через панель продавца. Каждый товар проходит модерацию перед публикацией. Комиссия платформы составляет от 5% до 15% в зависимости от категории товара. Средства от продажи поступают на ваш баланс после подтверждения получения товара покупателем. Есть ли у вас другие вопросы о продаже?",
                    'sets_context' => json_encode(['last_intent' => 'selling_explained'])
                ];
                break;
                
            default:
                // Если не знаем, что ожидаем, сбрасываем контекст
                return [
                    'response' => "Извините, я потерял нить нашего разговора. Чем я могу вам помочь?",
                    'sets_context' => json_encode(['last_intent' => 'reset'])
                ];
        }
    }
    
    /**
     * Персонализация ответа
     * 
     * @param string $response Исходный ответ
     * @return string Персонализированный ответ
     */
    private function personalizeResponse($response) {
        $userInfo = $this->getUserInfo();
        
        if ($userInfo) {
            // Добавляем имя пользователя в ответ, если это уместно
            if (strpos($response, 'Здравствуйте') === 0 || strpos($response, 'Добрый день') === 0) {
                $response = str_replace('!', ", {$userInfo['name']}!", $response);
            }
            
            // Персонализируем ответ в зависимости от роли пользователя
            if ($userInfo['role'] === 'seller' && strpos($this->message, 'продать') !== false) {
                $response .= "\n\nКак продавец, вы можете управлять своими товарами через панель продавца.";
            }
        }
        
        return $response;
    }
    
    /**
     * Обработка сообщения и получение ответа
     * 
     * @return array Результат обработки
     */
    public function processMessage() {
        // Проверяем, содержит ли сообщение ключевые слова для вызова оператора
        $operatorKeywords = ['оператор', 'человек', 'консультант', 'специалист', 'поддержка'];
        foreach ($operatorKeywords as $keyword) {
            if (strpos($this->message, $keyword) !== false) {
                // Обновляем контекст
                $this->saveContext(['last_intent' => 'operator_requested']);
                
                // Возвращаем ответ и флаг для перевода чата в режим ожидания оператора
                return [
                    'response' => "Сейчас я подключу вас к оператору поддержки. Пожалуйста, подождите немного. Оператор ответит вам в порядке очереди.",
                    'needOperator' => true
                ];
            }
        }
        
        // Ищем наиболее подходящий ответ
        $bestResponse = $this->findBestResponse();
        
        // Если нашли ответ
        if ($bestResponse) {
            $response = $bestResponse['response'];
            
            // Персонализируем ответ
            $response = $this->personalizeResponse($response);
            
            // Обновляем контекст, если нужно
            if (!empty($bestResponse['sets_context'])) {
                $newContext = is_string($bestResponse['sets_context']) 
                    ? json_decode($bestResponse['sets_context'], true) 
                    : $bestResponse['sets_context'];
                
                // Сохраняем предыдущий контекст для истории
                if (!empty($this->context)) {
                    $newContext['previous'] = $this->context;
                }
                
                $this->saveContext($newContext);
            }
            
            // Проверяем, нужно ли перевести чат в режим ожидания оператора
            $needOperator = strpos($response, 'подключу вас к оператору') !== false;
            
            return [
                'response' => $response,
                'needOperator' => $needOperator
            ];
        }
        
        // Если не нашли подходящего ответа
        return [
            'response' => "Извините, я не могу ответить на этот вопрос. Хотите, чтобы я подключил вас к оператору?",
            'needOperator' => false
        ];
    }
}

