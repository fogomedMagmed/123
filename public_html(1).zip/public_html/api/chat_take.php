<?php
// Начинаем сессию
session_start();

// Проверяем, авторизован ли пользователь и является ли он администратором
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
   header('Location: /login.php');
   exit;
}

// Проверяем, переданы ли необходимые параметры
if (!isset($_POST['chat_id'])) {
   header('Location: /admin/chats.php');
   exit;
}

// Получаем параметры
$chatId = (int)$_POST['chat_id'];
$operatorId = $_SESSION['user']['id'];

// Подключаемся к базе данных
require_once __DIR__ . '/../config/database.php';

// Проверяем, существует ли чат и находится ли он в режиме ожидания оператора
$stmt = $pdo->prepare("SELECT * FROM chats WHERE id = ? AND status = 'waiting_for_operator'");
$stmt->execute([$chatId]);
$chat = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$chat) {
   header('Location: /admin/chats.php?chat_id=' . $chatId);
   exit;
}

// Меняем статус чата на активный
$stmt = $pdo->prepare("UPDATE chats SET status = 'active' WHERE id = ?");
$stmt->execute([$chatId]);

// Проверяем, есть ли оператор в таблице операторов
$stmt = $pdo->prepare("SELECT * FROM operators WHERE user_id = ?");
$stmt->execute([$operatorId]);
$operator = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$operator) {
   // Если оператора нет в таблице, добавляем его
   $stmt = $pdo->prepare("INSERT INTO operators (user_id) VALUES (?)");
   $stmt->execute([$operatorId]);
   $operatorId = $pdo->lastInsertId();
} else {
   $operatorId = $operator['id'];
}

// Назначаем чат оператору
$stmt = $pdo->prepare("INSERT INTO chat_assignments (chat_id, operator_id) VALUES (?, ?)");
$stmt->execute([$chatId, $operatorId]);

// Добавляем сообщение от оператора
$stmt = $pdo->prepare("INSERT INTO chat_messages (chat_id, sender_type, sender_id, message) VALUES (?, 'operator', ?, 'Здравствуйте! Я оператор поддержки. Чем могу помочь?')");
$stmt->execute([$chatId, $_SESSION['user']['id']]);

// Перенаправляем на страницу чата
header('Location: /admin/chats.php?chat_id=' . $chatId);
exit;