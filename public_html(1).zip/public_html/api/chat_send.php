<?php
// Начинаем сессию
session_start();

// Проверяем, авторизован ли пользователь
if (!isset($_SESSION['user'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Необходимо авторизоваться']);
    exit;
}

// Проверяем, переданы ли необходимые параметры
if (!isset($_POST['chat_id']) || !isset($_POST['message'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Не указаны обязательные параметры']);
    exit;
}

// Получаем параметры
$chatId = (int)$_POST['chat_id'];
$message = trim($_POST['message']);
$userId = $_SESSION['user']['id'];

// Проверяем, не пустое ли сообщение
if (empty($message)) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Сообщение не может быть пустым']);
    exit;
}

// Подключаемся к базе данных
require_once __DIR__ . '/../config/database.php';

// Проверяем, принадлежит ли чат пользователю
$stmt = $pdo->prepare("SELECT * FROM chats WHERE id = ? AND user_id = ?");
$stmt->execute([$chatId, $userId]);
$chat = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$chat) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Чат не найден или не принадлежит пользователю']);
    exit;
}

// Проверяем, не закрыт ли чат
if ($chat['status'] === 'closed') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Чат закрыт']);
    exit;
}

// Сохраняем сообщение пользователя
$stmt = $pdo->prepare("INSERT INTO chat_messages (chat_id, sender_type, sender_id, message) VALUES (?, 'user', ?, ?)");
$stmt->execute([$chatId, $userId, $message]);

// Обновляем время последнего сообщения в чате
$stmt = $pdo->prepare("UPDATE chats SET updated_at = NOW() WHERE id = ?");
$stmt->execute([$chatId]);

// Проверяем, нужно ли перевести чат в режим ожидания оператора
$statusChanged = false;
$botResponse = null;

// Если чат уже ожидает оператора, не обрабатываем сообщение ботом
if ($chat['status'] !== 'waiting_for_operator') {
    // Подключаем умного бота
    require_once __DIR__ . '/smart_bot.php';
    $smartBot = new SmartBot($pdo, $chatId, $userId, $message);
    $botResult = $smartBot->processMessage();
    
    // Получаем ответ бота
    $botResponse = $botResult['response'];
    
    // Добавляем ответ бота в чат
    $stmt = $pdo->prepare("INSERT INTO chat_messages (chat_id, sender_type, message) VALUES (?, 'bot', ?)");
    $stmt->execute([$chatId, $botResponse]);
    
    // Если нужно перевести чат в режим ожидания оператора
    if ($botResult['needOperator']) {
        $stmt = $pdo->prepare("UPDATE chats SET status = 'waiting_for_operator' WHERE id = ?");
        $stmt->execute([$chatId]);
        $statusChanged = true;
    }
}

// Возвращаем успешный результат
header('Content-Type: application/json');
echo json_encode([
    'success' => true, 
    'botResponse' => $botResponse,
    'statusChanged' => $statusChanged
]);
exit;

